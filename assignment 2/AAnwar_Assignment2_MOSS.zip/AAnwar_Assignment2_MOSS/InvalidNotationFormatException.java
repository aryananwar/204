
public class InvalidNotationFormatException extends RuntimeException {
	public InvalidNotationFormatException()
	{
		super("Invalid notation");
	}

}
