
public class StackUnderflowException extends RuntimeException {
	public StackUnderflowException()
	{
		super("Stack has no elements!");
	}
	

}
